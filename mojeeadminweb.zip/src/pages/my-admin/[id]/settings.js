import React from 'react'

const settings = () => {
  return (
    <div>settings</div>
  )
}

export default settings